# Jakub Adamčiak
# Bakalárska práca
# Posilňované učenie na hre Bomberman

import os
import numpy as np
import sys
import time
import pickle
import random
import pandas as pd

def render_current(pic_array):
	for pic in pic_array:
		print(pd.DataFrame(pic), end="\n\n")
		time.sleep(0.5)

	print("##############################################################")
	if "c" in pic_array[-1]:
		print("\t\t\t\tWIN")
	else:
		print("\t\t\t\tLOSE")
	print("##############################################################")
	time.sleep(1)

def main():

	if os.path.exists("renders"):
		last_model = os.listdir("renders")[-1]
	render_dir = f"renders\\{last_model}\\"

	if len(sys.argv) < 2:
		file_to_open = os.listdir(render_dir)[-10:]
	else:
		file_to_open = sys.argv[1:]

	print(file_to_open)

	for file in file_to_open:
		file_path = f"{render_dir}{file}"
		if os.path.exists(file_path):
			with open(file_path, "rb") as f:
				x = pickle.load(f)
			render_current(x)

if __name__ == '__main__':
	main()
